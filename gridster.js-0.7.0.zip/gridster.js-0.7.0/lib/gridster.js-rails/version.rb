module Gridster
  module Rails
    VERSION = "0.7.0"
  end
end
