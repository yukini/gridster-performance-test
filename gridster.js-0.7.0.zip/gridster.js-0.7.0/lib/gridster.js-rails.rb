module Gridster
  module Rails
    require "gridster.js-rails/engine"
  end
end
